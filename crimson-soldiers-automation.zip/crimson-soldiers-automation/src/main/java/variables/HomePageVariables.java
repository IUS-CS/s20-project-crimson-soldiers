package variables;

public class HomePageVariables {

}
