package variables;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import setup.CommonDriverClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class CommonVariables {
    public static ExtentReports report;
    public static ExtentTest test;

    public CommonVariables() {
    }

    public static WebElement getExternalEAMLoginBtn() {
        return CommonDriverClass.driver.findElement(By.xpath("//button[@value='Log In']"));
    }

    public static WebElement getExternalEAMUserNameTxtBox() {
        return CommonDriverClass.driver.findElement(By.id("userName"));
    }

    public static WebElement getExternalEAMPasswordTxtBox() {
        return CommonDriverClass.driver.findElement(By.id("password"));
    }
}
