package variables;

public class ServiceSpecificVariables {

}
