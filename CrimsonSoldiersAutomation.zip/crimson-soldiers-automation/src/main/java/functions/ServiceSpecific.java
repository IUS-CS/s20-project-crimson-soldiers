package functions;

public class ServiceSpecific {
}
