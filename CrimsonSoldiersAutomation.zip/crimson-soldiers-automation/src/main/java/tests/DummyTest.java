package tests;

import org.testng.annotations.Test;

public class DummyTest {
	
	@Test
	public static void AutomatedTest() {

	}
}
