package tests;

import org.testng.annotations.Test;

public class MainTest {
	
	@Test
	public static void AutomatedTest() {

	}
}
